#include <iostream>
 
using namespace std;
int main() {
    int nam;
    int soNguyen1,soNguyen2;//Khai bao 2 so nguyen
    cout<<"Nhap vao 2 so nguyen : ";
    cin>>soNguyen1>>soNguyen2;//Nhap vao 2 so nguyen
    cout<<soNguyen1<<" "<<soNguyen2<<endl;//In ra 2 so nguyen
    cout<<soNguyen1/soNguyen2<<" "<<soNguyen1%soNguyen2<<endl;//In ra phan nguyen va du cua 2 so nguyen
    return 0;
}