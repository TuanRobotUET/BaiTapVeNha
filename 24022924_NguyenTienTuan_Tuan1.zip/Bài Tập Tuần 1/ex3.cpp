#include <iostream>
 
using namespace std;
int main() {
    int nam;
    cout<<"Nam hien tai la bao nhieu : ";
    cin>>nam;
    cout<<"Xin chao"<<endl;
    cout<<"Ban dang hoc lap trình C vao nam "<<nam;
    return 0;
}