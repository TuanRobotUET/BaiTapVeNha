#include <iostream>
 
using namespace std;
int main() {
    int soNguyen;//Khai bao so nguyen
    double soThuc;//Khai bao so thuc
    char kiTu;//Khai bao ki tu
    cout<<"Nhap vao so nguyen, so thuc, ki tu : ";
    cin>>soNguyen>>soThuc>>kiTu;//Nhap vao so nguyen , so thuc , ki tu
    cout<<soNguyen<<" "<<soThuc<<" "<<kiTu;//In ra lan luot
    return 0;
}