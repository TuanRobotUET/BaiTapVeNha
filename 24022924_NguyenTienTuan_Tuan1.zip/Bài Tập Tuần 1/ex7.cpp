#include <iostream>
 
using namespace std;
int main() {
    int ngaySinh,thangSinh,namSinh;//Khai bao ngay thang nam sinh
    cout<<"Nhap vao ngay, thang, nam sinh cua ban : ";
    cin>>ngaySinh>>thangSinh>>namSinh;//Nhap vao ngay, thang, nam sinh
    cout<<"Nhap thang nam sinh cua ban la : "<<ngaySinh<<"/"<<thangSinh<<"/"<<namSinh;//Xuat ra man hinh ngay thang nam sinh theo mau
    return 0;
}