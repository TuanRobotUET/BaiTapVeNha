#include <iostream>
 
using namespace std;
int main() {
    double tienHan,tienViet;//Khai bao tien viet va han
    cout<<"Nhap so tien Han : ";
    cin>>tienHan;//Nhap tien han
    tienViet=tienHan*18.7;//Quy doi tien han sang viet
    cout<<"So tien Viet da duoc quy doi la : "<<tienViet;//Xuat ra so tien Viet
    return 0;
}